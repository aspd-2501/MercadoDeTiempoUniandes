/* eslint-disable prettier/prettier */
/* archivo: src/acuerdo/acuerdo.module.ts */
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AcuerdoService } from './acuerdo.service';
import { AcuerdoEntity } from './acuerdo.entity';
import { ParticipanteAcuerdoEntity } from './participante-acuerdo.entity';
import { PerfilMiembroEntity } from '../perfil-miembro/perfil-miembro.entity';
import { HorarioDisponibleEntity } from '../horario-disponible/horario-disponible.entity';
import { ChatEntity } from '../chat/chat.entity';
import { TransaccionEntity } from '../transaccion/transaccion.entity';
import { AcuerdoController } from './acuerdo.controller';
import { DisponibilidadAcuerdoService } from './disponibilidad-acuerdo.service';
import { DisponibilidadAcuerdoController } from './disponibilidad-acuerdo.controller';

@Module({
    imports: [TypeOrmModule.forFeature([AcuerdoEntity, ParticipanteAcuerdoEntity, PerfilMiembroEntity, HorarioDisponibleEntity, ChatEntity, TransaccionEntity])],
    providers: [AcuerdoService, DisponibilidadAcuerdoService],
    controllers: [AcuerdoController, DisponibilidadAcuerdoController],
})
export class AcuerdoModule {}