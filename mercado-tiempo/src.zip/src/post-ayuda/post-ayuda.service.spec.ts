/* eslint-disable prettier/prettier */
/* archivo: src/post-ayuda/post-ayuda.service.spec.ts */
import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { faker } from '@faker-js/faker';
import { TypeOrmTestingConfig } from '../shared/testing-utils/typeorm-testing-config';
import { AcuerdoEntity } from '../acuerdo/acuerdo.entity';
import { ParticipanteAcuerdoEntity, RolParticipante } from '../acuerdo/participante-acuerdo.entity';
import { FranjaHoraria, PostAyudaService } from './post-ayuda.service';
import { PostAyudaEntity } from './post-ayuda.entity';
import { PostAyudaCategoriaEntity } from './post-ayuda-categoria.entity';
import { PerfilMiembroEntity } from '../perfil-miembro/perfil-miembro.entity';
import { UsuarioEntity } from '../usuario/usuario.entity';
import { CategoriaEntity } from '../categoria/categoria.entity';
import { HorarioDisponibleEntity } from '../horario-disponible/horario-disponible.entity';

describe('PostAyudaService', () => {
    let service: PostAyudaService;
    let postAyudaRepository: Repository<PostAyudaEntity>;
    let perfilRepository: Repository<PerfilMiembroEntity>;
    let usuarioRepository: Repository<UsuarioEntity>;
    let categoriaRepository: Repository<CategoriaEntity>;
    let postCategoriaRepository: Repository<PostAyudaCategoriaEntity>;
    let horarioRepository: Repository<HorarioDisponibleEntity>;

    let perfil: PerfilMiembroEntity;
    let categoriasList: CategoriaEntity[];
    let post: PostAyudaEntity;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports: [...TypeOrmTestingConfig()],
            providers: [PostAyudaService],
        }).compile();

        service = module.get<PostAyudaService>(PostAyudaService);
        postAyudaRepository = module.get<Repository<PostAyudaEntity>>(getRepositoryToken(PostAyudaEntity));
        perfilRepository = module.get<Repository<PerfilMiembroEntity>>(getRepositoryToken(PerfilMiembroEntity));
        usuarioRepository = module.get<Repository<UsuarioEntity>>(getRepositoryToken(UsuarioEntity));
        categoriaRepository = module.get<Repository<CategoriaEntity>>(getRepositoryToken(CategoriaEntity));
        postCategoriaRepository = module.get<Repository<PostAyudaCategoriaEntity>>(getRepositoryToken(PostAyudaCategoriaEntity));
        horarioRepository = module.get<Repository<HorarioDisponibleEntity>>(getRepositoryToken(HorarioDisponibleEntity));

        await seedDatabase();
    });

    const createPerfil = async (): Promise<PerfilMiembroEntity> => {
        const usuario: UsuarioEntity = await usuarioRepository.save({
            idUniandes: faker.string.alphanumeric(10),
            contrasenia: faker.internet.password(),
        });

        return await perfilRepository.save({
            imagen: faker.image.url(),
            descripcion: faker.lorem.sentence(),
            nombre: faker.person.fullName(),
            edad: faker.number.int({ min: 18, max: 60 }),
            afiliacionUniandes: "Estudiante",
            estadoActividad: true,
            saldo: faker.number.int({ min: 0, max: 100 }),
            usuario,
        });
    };

    // Franja que empieza mañana y dura `duracionHoras` horas
    const crearFranja = (duracionHoras: number): FranjaHoraria => {
        const fechaInicio = faker.date.soon({ days: 30 });
        const fechaFin = new Date(fechaInicio.getTime() + duracionHoras * 60 * 60 * 1000);
        return { fechaInicio, fechaFin };
    };

    const seedDatabase = async () => {
        await horarioRepository.clear();
        await postCategoriaRepository.clear();
        await postAyudaRepository.clear();
        await categoriaRepository.clear();
        await perfilRepository.clear();
        await usuarioRepository.clear();

        perfil = await createPerfil();

        categoriasList = [];
        for (let i = 0; i < 5; i++) {
            categoriasList.push(await categoriaRepository.save({ nombre: faker.commerce.department() }));
        }

        post = await postAyudaRepository.save({
            titulo: faker.lorem.words(3),
            descripcion: faker.lorem.sentence(),
            imagen: faker.image.url(),
            ofrece: true,
            cupo: 2,
            cupoLleno: false,
            horas: faker.number.int({ min: 1, max: 10 }),
            fechaCreacion: faker.date.recent(),
            perfilAutor: perfil,
        });

        await postCategoriaRepository.save({ idPostAyuda: post.id, idCategoria: categoriasList[0].id });
        await postCategoriaRepository.save({ idPostAyuda: post.id, idCategoria: categoriasList[1].id });

        await horarioRepository.save({ ...crearFranja(post.horas), postAyuda: post, perfil });
    };

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('create should save a post ayuda with 1 to 3 categorias', async () => {
        const nuevoPost: PostAyudaEntity = {
            id: "",
            titulo: faker.lorem.words(3),
            descripcion: faker.lorem.sentence(),
            imagen: faker.image.url(),
            ofrece: false,
            cupo: 1,
            cupoLleno: false,
            horas: faker.number.int({ min: 1, max: 10 }),
            fechaCreacion: faker.date.recent(),
            perfilAutor: perfil,
        } as PostAyudaEntity;

        const result = await service.create(nuevoPost, [categoriasList[2].id], [crearFranja(nuevoPost.horas)]);
        expect(result).not.toBeNull();
        expect(result.categorias.length).toBe(1);
        expect(result.horariosDisponibles.length).toBe(1);
    });

    it('create should save several horarios disponibles', async () => {
        const nuevoPost: PostAyudaEntity = {
            id: "",
            titulo: faker.lorem.words(3),
            descripcion: faker.lorem.sentence(),
            imagen: faker.image.url(),
            ofrece: true,
            cupo: 1,
            cupoLleno: false,
            horas: 2,
            fechaCreacion: faker.date.recent(),
            perfilAutor: perfil,
        } as PostAyudaEntity;

        const result = await service.create(nuevoPost, [categoriasList[2].id], [crearFranja(2), crearFranja(3), crearFranja(5)]);
        expect(result.horariosDisponibles.length).toBe(3);
    });

    it('create should throw an exception without horarios', async () => {
        const nuevoPost: PostAyudaEntity = {
            id: "",
            titulo: faker.lorem.words(3),
            descripcion: faker.lorem.sentence(),
            imagen: faker.image.url(),
            ofrece: true,
            cupo: 1,
            cupoLleno: false,
            horas: 2,
            fechaCreacion: faker.date.recent(),
            perfilAutor: perfil,
        } as PostAyudaEntity;

        await expect(() => service.create(nuevoPost, [categoriasList[2].id], []))
            .rejects.toHaveProperty("message", "Un post de ayuda debe tener al menos 1 horario disponible");
    });

    it('create should throw an exception for a horario shorter than the horas of the post', async () => {
        const nuevoPost: PostAyudaEntity = {
            id: "",
            titulo: faker.lorem.words(3),
            descripcion: faker.lorem.sentence(),
            imagen: faker.image.url(),
            ofrece: true,
            cupo: 1,
            cupoLleno: false,
            horas: 3,
            fechaCreacion: faker.date.recent(),
            perfilAutor: perfil,
        } as PostAyudaEntity;

        await expect(() => service.create(nuevoPost, [categoriasList[2].id], [crearFranja(3), crearFranja(1)]))
            .rejects.toHaveProperty("message", "Cada horario debe durar al menos las horas del post de ayuda");
    });

    it('create should throw an exception for a horario that ends before it starts', async () => {
        const nuevoPost: PostAyudaEntity = {
            id: "",
            titulo: faker.lorem.words(3),
            descripcion: faker.lorem.sentence(),
            imagen: faker.image.url(),
            ofrece: true,
            cupo: 1,
            cupoLleno: false,
            horas: 1,
            fechaCreacion: faker.date.recent(),
            perfilAutor: perfil,
        } as PostAyudaEntity;
        const { fechaInicio, fechaFin } = crearFranja(2);

        await expect(() => service.create(nuevoPost, [categoriasList[2].id], [{ fechaInicio: fechaFin, fechaFin: fechaInicio }]))
            .rejects.toHaveProperty("message", "El horario debe terminar después de empezar");
    });

    it('create should throw an exception without a perfil autor', async () => {
        const nuevoPost: PostAyudaEntity = {
            id: "",
            titulo: faker.lorem.words(3),
            descripcion: faker.lorem.sentence(),
            imagen: faker.image.url(),
            ofrece: false,
            cupo: 1,
            cupoLleno: false,
            horas: faker.number.int({ min: 1, max: 10 }),
            fechaCreacion: faker.date.recent(),
        } as PostAyudaEntity;

        await expect(() => service.create(nuevoPost, [categoriasList[2].id], [crearFranja(nuevoPost.horas)]))
            .rejects.toHaveProperty("message", "Un post de ayuda debe tener un autor");
    });

    it('create should throw an exception for an invalid perfil autor', async () => {
        const invalidPerfil: PerfilMiembroEntity = { id: "0" } as PerfilMiembroEntity;
        const nuevoPost: PostAyudaEntity = {
            id: "",
            titulo: faker.lorem.words(3),
            descripcion: faker.lorem.sentence(),
            imagen: faker.image.url(),
            ofrece: false,
            cupo: 1,
            cupoLleno: false,
            horas: faker.number.int({ min: 1, max: 10 }),
            fechaCreacion: faker.date.recent(),
            perfilAutor: invalidPerfil,
        } as PostAyudaEntity;

        await expect(() => service.create(nuevoPost, [categoriasList[2].id], [crearFranja(nuevoPost.horas)]))
            .rejects.toHaveProperty("message", "No se encontró el perfil del autor");
    });

    it('create should throw an exception with no categorias', async () => {
        const nuevoPost: PostAyudaEntity = {
            id: "",
            titulo: faker.lorem.words(3),
            descripcion: faker.lorem.sentence(),
            imagen: faker.image.url(),
            ofrece: false,
            cupo: 1,
            cupoLleno: false,
            horas: faker.number.int({ min: 1, max: 10 }),
            fechaCreacion: faker.date.recent(),
            perfilAutor: perfil,
        } as PostAyudaEntity;

        await expect(() => service.create(nuevoPost, [], [crearFranja(nuevoPost.horas)]))
            .rejects.toHaveProperty("message", "Un post de ayuda debe tener entre 1 y 3 categorías");
    });

    it('create should throw an exception with more than 3 categorias', async () => {
        const nuevoPost: PostAyudaEntity = {
            id: "",
            titulo: faker.lorem.words(3),
            descripcion: faker.lorem.sentence(),
            imagen: faker.image.url(),
            ofrece: false,
            cupo: 1,
            cupoLleno: false,
            horas: faker.number.int({ min: 1, max: 10 }),
            fechaCreacion: faker.date.recent(),
            perfilAutor: perfil,
        } as PostAyudaEntity;

        const ids = categoriasList.slice(0, 4).map(c => c.id);
        await expect(() => service.create(nuevoPost, ids, [crearFranja(nuevoPost.horas)]))
            .rejects.toHaveProperty("message", "Un post de ayuda debe tener entre 1 y 3 categorías");
    });

    it('create should throw an exception for an invalid categoria', async () => {
        const nuevoPost: PostAyudaEntity = {
            id: "",
            titulo: faker.lorem.words(3),
            descripcion: faker.lorem.sentence(),
            imagen: faker.image.url(),
            ofrece: false,
            cupo: 1,
            cupoLleno: false,
            horas: faker.number.int({ min: 1, max: 10 }),
            fechaCreacion: faker.date.recent(),
            perfilAutor: perfil,
        } as PostAyudaEntity;

        await expect(() => service.create(nuevoPost, ["0"], [crearFranja(nuevoPost.horas)]))
            .rejects.toHaveProperty("message", "No se encontró la categoría");
    });

    it('findOne should return a post ayuda by id', async () => {
        const result = await service.findOne(post.id);
        expect(result).not.toBeNull();
        expect(result.categorias.length).toBe(2);
    });

    it('findOne should throw an exception for an invalid post ayuda', async () => {
        await expect(() => service.findOne("0"))
            .rejects.toHaveProperty("message", "No se encontró el post de ayuda");
    });

    it('update should modify a post ayuda', async () => {
        post.titulo = faker.lorem.words(3);
        const updated = await service.update(post.id, post);
        expect(updated.titulo).toBe(post.titulo);
    });

    it('update should ignore the cupoLleno sent and recalculate it when the cupo changes', async () => {
        // Un miembro ya ocupa un cupo del post (cupo 1)
        const otro = await perfilRepository.save({ ...perfil, id: undefined, usuario: undefined, nombre: 'Otro' } as any);
        const acuerdo = await postAyudaRepository.manager.save(AcuerdoEntity, { horas: 2, fechaCreacion: new Date(), estado: 0, postAyuda: post });
        await postAyudaRepository.manager.save(ParticipanteAcuerdoEntity, { idAcuerdo: acuerdo.id, idPerfil: otro.id, rol: RolParticipante.RECEPTOR });

        const lleno = await service.update(post.id, { ...post, cupo: 1, cupoLleno: false } as PostAyudaEntity);
        expect(lleno.cupoLleno).toBe(true);

        const conMasCupo = await service.update(post.id, { ...post, cupo: 3, cupoLleno: true } as PostAyudaEntity);
        expect(conMasCupo.cupoLleno).toBe(false);
    });

    it('update should throw an exception for an invalid post ayuda', async () => {
        const invalidPost = { ...post, titulo: faker.lorem.words(3) };
        await expect(() => service.update("0", invalidPost))
            .rejects.toHaveProperty("message", "No se encontró el post de ayuda");
    });

    it('findCategoriasByPostId should return the categorias of a post', async () => {
        const categorias = await service.findCategoriasByPostId(post.id);
        expect(categorias.length).toBe(2);
    });

    it('findCategoriasByPostId should throw an exception for an invalid post ayuda', async () => {
        await expect(() => service.findCategoriasByPostId("0"))
            .rejects.toHaveProperty("message", "No se encontró el post de ayuda");
    });

    it('associateCategoriasPost should update the categorias of a post', async () => {
        const result = await service.associateCategoriasPost(post.id, [categoriasList[3].id]);
        expect(result.categorias.length).toBe(1);
    });

    it('associateCategoriasPost should throw an exception for an invalid post ayuda', async () => {
        await expect(() => service.associateCategoriasPost("0", [categoriasList[3].id]))
            .rejects.toHaveProperty("message", "No se encontró el post de ayuda");
    });

    it('associateCategoriasPost should throw an exception with more than 3 categorias', async () => {
        const ids = categoriasList.slice(0, 4).map(c => c.id);
        await expect(() => service.associateCategoriasPost(post.id, ids))
            .rejects.toHaveProperty("message", "Un post de ayuda debe tener entre 1 y 3 categorías");
    });

    it('delete should remove a post ayuda', async () => {
        await service.delete(post.id);
        const deleted = await postAyudaRepository.findOne({ where: { id: post.id } });
        expect(deleted).toBeNull();
    });

    it('delete should throw an exception for an invalid post ayuda', async () => {
        await expect(() => service.delete("0"))
            .rejects.toHaveProperty("message", "No se encontró el post de ayuda");
    });

    it('findHorariosByPostId should return the horarios of a post', async () => {
        const horarios = await service.findHorariosByPostId(post.id);
        expect(horarios.length).toBe(1);
    });

    it('findHorariosByPostId should throw an exception for an invalid post ayuda', async () => {
        await expect(() => service.findHorariosByPostId("0"))
            .rejects.toHaveProperty("message", "No se encontró el post de ayuda");
    });

    it('addHorarioPost should add a horario to a post', async () => {
        const result = await service.addHorarioPost(post.id, crearFranja(post.horas));
        expect(result.horariosDisponibles.length).toBe(2);
    });

    it('addHorarioPost should throw an exception for a horario shorter than the horas of the post', async () => {
        await service.update(post.id, { ...post, horas: 4 });
        await expect(() => service.addHorarioPost(post.id, crearFranja(2)))
            .rejects.toHaveProperty("message", "Cada horario debe durar al menos las horas del post de ayuda");
    });

    it('deleteHorarioPost should remove a horario from a post', async () => {
        const conDos = await service.addHorarioPost(post.id, crearFranja(post.horas));
        await service.deleteHorarioPost(post.id, conDos.horariosDisponibles[0].id);
        const horarios = await service.findHorariosByPostId(post.id);
        expect(horarios.length).toBe(1);
    });

    it('deleteHorarioPost should throw an exception when it would leave 0 horarios', async () => {
        const [unico] = await service.findHorariosByPostId(post.id);
        await expect(() => service.deleteHorarioPost(post.id, unico.id))
            .rejects.toHaveProperty("message", "Un post de ayuda debe conservar al menos 1 horario disponible");
    });

    it('deleteHorarioPost should throw an exception for a horario of another post', async () => {
        await expect(() => service.deleteHorarioPost(post.id, "0"))
            .rejects.toHaveProperty("message", "El horario disponible no pertenece al post de ayuda");
    });

    // --- Horario preferido (preferencia inicial del autor; el horario final se define en el acuerdo) ---

    const datosPost = (): PostAyudaEntity => ({
        titulo: faker.lorem.words(3), descripcion: faker.lorem.sentence(), imagen: faker.image.url(),
        ofrece: true, cupo: 1, cupoLleno: false, horas: 2, fechaCreacion: faker.date.recent(), perfilAutor: perfil,
    }) as PostAyudaEntity;

    // Franja de 3 horas que empieza el 1 de diciembre de 2026 a la hora indicada (UTC)
    const franjaA = (hora: number, preferido?: boolean): FranjaHoraria => ({
        fechaInicio: new Date(Date.UTC(2026, 11, 1, hora)), fechaFin: new Date(Date.UTC(2026, 11, 1, hora + 3)), preferido,
    });
    const preferidas = (horarios: HorarioDisponibleEntity[]) => horarios.filter(h => h.preferido).map(h => new Date(h.fechaInicio).getUTCHours());

    it('create should save the horario marked as preferido', async () => {
        const result = await service.create(datosPost(), [categoriasList[0].id], [franjaA(8), franjaA(14, true), franjaA(10)]);
        expect(preferidas(result.horariosDisponibles)).toEqual([14]);
    });

    it('create should use the earliest horario as preferido when none is marked', async () => {
        const result = await service.create(datosPost(), [categoriasList[0].id], [franjaA(14), franjaA(8), franjaA(10)]);
        expect(preferidas(result.horariosDisponibles)).toEqual([8]);
    });

    it('create should throw an exception with more than one preferido', async () => {
        await expect(() => service.create(datosPost(), [categoriasList[0].id], [franjaA(8, true), franjaA(14, true)]))
            .rejects.toHaveProperty("message", "Solo un horario del post de ayuda puede ser el preferido");
    });

    it('marcarHorarioPreferido should change the preferido horario', async () => {
        const creado = await service.create(datosPost(), [categoriasList[0].id], [franjaA(8, true), franjaA(14)]);
        const tarde = creado.horariosDisponibles.find(h => new Date(h.fechaInicio).getUTCHours() === 14)!;

        const result = await service.marcarHorarioPreferido(creado.id, tarde.id);
        expect(preferidas(result.horariosDisponibles)).toEqual([14]);
    });

    it('marcarHorarioPreferido should throw an exception for a horario of another post', async () => {
        const creado = await service.create(datosPost(), [categoriasList[0].id], [franjaA(8)]);
        const [delOtro] = await service.findHorariosByPostId(post.id);
        await expect(() => service.marcarHorarioPreferido(creado.id, delOtro.id))
            .rejects.toHaveProperty("message", "El horario disponible no pertenece al post de ayuda");
    });

    it('marcarHorarioPreferido should throw an exception for an invalid post ayuda', async () => {
        await expect(() => service.marcarHorarioPreferido("0", "0"))
            .rejects.toHaveProperty("message", "No se encontró el post de ayuda");
    });

    it('addHorarioPost should keep the preferido unless the new horario is marked', async () => {
        const creado = await service.create(datosPost(), [categoriasList[0].id], [franjaA(8)]);
        const sinMarcar = await service.addHorarioPost(creado.id, franjaA(10));
        expect(preferidas(sinMarcar.horariosDisponibles)).toEqual([8]);

        const marcado = await service.addHorarioPost(creado.id, franjaA(16, true));
        expect(preferidas(marcado.horariosDisponibles)).toEqual([16]);
    });

    it('deleteHorarioPost should make the earliest horario preferido when the preferido is removed', async () => {
        const creado = await service.create(datosPost(), [categoriasList[0].id], [franjaA(16), franjaA(14, true), franjaA(10)]);
        const preferido = creado.horariosDisponibles.find(h => h.preferido)!;

        await service.deleteHorarioPost(creado.id, preferido.id);
        expect(preferidas(await service.findHorariosByPostId(creado.id))).toEqual([10]);
    });

    // --- Posts de ayuda de un perfil ("Mis posts") ---

    const postDe = async (autor: PerfilMiembroEntity, titulo: string, ofrece: boolean, dia: number, cupoLleno = false) => {
        const nuevo = await postAyudaRepository.save({
            titulo, descripcion: 'd', imagen: 'i', ofrece, cupo: 1, cupoLleno, horas: 2,
            fechaCreacion: new Date(Date.UTC(2026, 10, dia)), perfilAutor: autor,
        });
        await horarioRepository.save({ fechaInicio: new Date(Date.UTC(2026, 11, dia, 10)), fechaFin: new Date(Date.UTC(2026, 11, dia, 14)), postAyuda: nuevo, perfil: autor });
        await horarioRepository.save({ fechaInicio: new Date(Date.UTC(2026, 11, dia, 8)), fechaFin: new Date(Date.UTC(2026, 11, dia, 10)), postAyuda: nuevo, perfil: autor });
        return nuevo;
    };

    it('findByPerfilAutor should return only the posts of the perfil, newest first, with categorias and horarios', async () => {
        const autor = await perfilRepository.save({ ...perfil, id: undefined, usuario: undefined, nombre: 'Autora' } as any);
        await postDe(autor, 'Viejo', true, 1);
        await postDe(autor, 'Nuevo', false, 9, true);
        await postAyudaRepository.save({ titulo: 'De otro', descripcion: 'd', imagen: 'i', ofrece: true, cupo: 1, cupoLleno: false, horas: 2, fechaCreacion: new Date(), perfilAutor: perfil });

        const result = await service.findByPerfilAutor(autor.id);
        expect(result.map(p => p.titulo)).toEqual(['Nuevo', 'Viejo']);
        expect(result[0].cupoLleno).toBe(true);
        expect(result[0].perfilAutor.id).toBe(autor.id);
        expect(result[0].horariosDisponibles.map(h => new Date(h.fechaInicio).getUTCHours())).toEqual([8, 10]);
        expect(Array.isArray(result[0].categorias)).toBe(true);
    });

    it('findByPerfilAutor should filter by ofrece', async () => {
        const autor = await perfilRepository.save({ ...perfil, id: undefined, usuario: undefined, nombre: 'Autora' } as any);
        await postDe(autor, 'Ofrezco', true, 1);
        await postDe(autor, 'Necesito', false, 2);
        expect((await service.findByPerfilAutor(autor.id, true)).map(p => p.titulo)).toEqual(['Ofrezco']);
        expect((await service.findByPerfilAutor(autor.id, false)).map(p => p.titulo)).toEqual(['Necesito']);
    });

    it('findByPerfilAutor should throw an exception for an invalid perfil', async () => {
        await expect(() => service.findByPerfilAutor("0")).rejects.toHaveProperty("message", "No se encontró el perfil de miembro");
    });
});
