import { useState, useEffect } from 'react';
import { useParams } from 'react-router';
import { useMiembroSesion } from '../../contextos/MiembroSesionContext';
import {
  ArrowLeft,
  CalendarDays,
  Check,
  CircleCheck,
  CircleHelp,
  Clock3,
  Star,
  TriangleAlert,
  UsersRound,
} from 'lucide-react';
import type { LucideIcon, LucideProps } from 'lucide-react';
import { MIEMBROS_DEMO } from '../../mocks/miembros.mocks';
import { PUBLICACIONES_DEMO } from '../../mocks/postsAyuda.mocks';
import { CalendarioDisponibilidadPostAyuda } from '../../componentes/calendario/CalendarioDisponibilidad';
import type { DatosPostAyuda } from '../../tipos/postAyuda';
import {
  obtenerPostAyuda,
  obtenerCategoriasPost,
  type PostAyudaAPI,
  type HorarioPostAPI,
  type CategoriaPostAPI,
} from '../../api/postsAyuda.api';
import type { IntervaloDisponibilidad } from '../../tipos/disponibilidad';
import { obtenerAcuerdosMiembro } from '../../api/acuerdos.api';

/**
 * Detalle de /posts/:postId. Consulta el post real y permite unirse mediante
 * POST /acuerdos/iniciar a través de App; calendario y coincidencias son del backend.
 * Los mocks se conservan únicamente para visualizar ejemplos antiguos.
 */
export type TipoPostAyuda = 'help-offer' | 'help-request';

/** Mismo modelo compartido que utiliza la tarjeta PostAyuda y PUBLICACIONES_DEMO. */
export type PostAyuda = DatosPostAyuda;

export interface AutorPostAyuda {
  id: string;
  name: string;
  firstName: string;
  faculty?: string;
  avatar?: string;
  avatarColor?: string;
}

export interface ResultadoParticipacion {
  acuerdoId: string;
  chatId?: string;
}

export interface PostAyudaDetailProps {
  onBack?: () => void;
  onVerPerfil?: (miembroId: string) => void;
  /** Un único POST transaccional registra la participación; nunca varios POST desde React. */
  onParticipar?: (postId: string) => Promise<ResultadoParticipacion>;
  onVerAcuerdo?: (acuerdoId: string) => void;
  /** Los chats se abren siempre desde el ID del acuerdo, no desde un chat independiente. */
  onIrChat?: (acuerdoId: string) => void;
  onVolverInicio?: () => void;
}

// ─── Formato local para la presentación del horario preferido ───
// Estas funciones solo transforman textos; no comparan ni asignan disponibilidades.
function mostrarFechaISO(fecha: string): string {
  const fechaLocal = new Date(`${fecha}T12:00:00`);
  if (Number.isNaN(fechaLocal.getTime())) return fecha;
  return new Intl.DateTimeFormat('es-CO', { dateStyle: 'long' }).format(fechaLocal);
}

function mostrarHora24(hora: string): string {
  const coincidencia = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(hora);
  if (!coincidencia) return hora;
  const h = Number(coincidencia[1]);
  return `${h % 12 || 12}:${coincidencia[2]} ${h < 12 ? 'a. m.' : 'p. m.'}`;
}

// Los horarios llegan en ISO desde NestJS; solo convertimos para el calendario.
function mostrarDiaLocal(fecha: Date): string {
  const dia = String(fecha.getDate()).padStart(2, '0');
  const mes = String(fecha.getMonth() + 1).padStart(2, '0');
  return `${fecha.getFullYear()}-${mes}-${dia}`;
}

function mostrarHoraLocal(fecha: Date): string {
  return `${String(fecha.getHours()).padStart(2, '0')}:${String(fecha.getMinutes()).padStart(2, '0')}`;
}

function horarioParaCalendario(horario: HorarioPostAPI): IntervaloDisponibilidad {
  const inicio = new Date(horario.fechaInicio);
  const fin = new Date(horario.fechaFin);
  return {
    id: horario.id,
    date: mostrarDiaLocal(inicio),
    startTime: mostrarHoraLocal(inicio),
    endTime: mostrarHoraLocal(fin),
  };
}

function esPostDelBackend(post: DatosPostAyuda | PostAyudaAPI): post is PostAyudaAPI {
  return 'ofrece' in post;
}

// Iconos y componentes auxiliares.
const ICONOS = {
  check: Check,
  'arrow-left': ArrowLeft,
  star: Star,
  'alert-triangle': TriangleAlert,
  'check-circle': CircleCheck,
  calendar: CalendarDays,
  clock: Clock3,
  users: UsersRound,
  'help-circle': CircleHelp,
} satisfies Record<string, LucideIcon>;

type NombreIcono = keyof typeof ICONOS;

function Icon({ name, ...props }: { name: NombreIcono } & Omit<LucideProps, 'name'>) {
  const Componente = ICONOS[name];
  return <Componente aria-hidden="true" {...props} />;
}

function Avatar({
  name,
  avatarUrl,
  avatarColor = '#3C9DA0',
}: {
  name: string;
  avatarUrl?: string;
  avatarColor?: string;
  size?: 'md';
}) {
  const iniciales = name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((parte) => parte[0]?.toUpperCase() ?? '')
    .join('');
  return (
    <span
      className="w-10 h-10 rounded-full shrink-0 inline-flex items-center justify-center overflow-hidden text-white text-sm font-semibold"
      style={{ backgroundColor: avatarColor }}
      aria-label={name}
    >
      {avatarUrl ? (
        <img src={avatarUrl} alt="" className="w-full h-full object-cover" />
      ) : (
        iniciales
      )}
    </span>
  );
}

function Chip({ label }: { label: string; size?: 'sm'; color?: 'teal' }) {
  return (
    <span className="inline-flex items-center rounded-full bg-[#E8F5F6] px-2.5 py-1 text-xs font-medium text-[#3C9DA0]">
      {label}
    </span>
  );
}

export default function PostAyudaDetail({
  onBack,
  onVerPerfil,
  onParticipar,
  onVerAcuerdo,
  onIrChat,
  onVolverInicio,
}: PostAyudaDetailProps) {

  // 01. IDENTIFICAR LA PUBLICACIÓN
  const { postId } = useParams<{ postId: string }>();

  // 02. OBTENER EL MIEMBRO AUTENTICADO
  const { perfil } = useMiembroSesion();
  const currentUserId = perfil?.id ?? '';

  // 03. BUSCAR LA PUBLICACIÓN: los mocks antiguos siguen sirviendo para Home,
  // pero los UUID de Explorar se consultan por API real.
  const postDemo = PUBLICACIONES_DEMO.find((publicacion) => publicacion.id === postId);
  const [respuestaApi, setRespuestaApi] = useState<PostAyudaAPI | null>(null);
  const [categoriasApi, setCategoriasApi] = useState<CategoriaPostAPI[]>([]);
  const [cargandoPost, setCargandoPost] = useState(false);
  const [errorPost, setErrorPost] = useState<string | null>(null);
  const [reintentarConsulta, setReintentarConsulta] = useState(0);

  useEffect(() => {
    let vigente = true;
    setRespuestaApi(null);
    setCategoriasApi([]);
    setErrorPost(null);

    if (!postId || postDemo) {
      setCargandoPost(false);
      return () => { vigente = false; };
    }

    setCargandoPost(true);
    void Promise.allSettled([
      obtenerPostAyuda(postId),
      obtenerCategoriasPost(postId),
    ]).then(([post, categorias]) => {
      if (!vigente) return;
      if (post.status === 'rejected') {
        setErrorPost(post.reason instanceof Error ? post.reason.message : 'No se pudo consultar la publicación.');
      } else {
        setRespuestaApi(post.value);
        if (categorias.status === 'fulfilled') setCategoriasApi(categorias.value);
      }
    }).finally(() => {
      if (vigente) setCargandoPost(false);
    });
    return () => { vigente = false; };
  }, [postId, postDemo, reintentarConsulta]);

  const post = postDemo ?? (respuestaApi?.id === postId ? respuestaApi : undefined);
  const author: AutorPostAyuda | undefined = post
    ? esPostDelBackend(post)
      ? {
          id: post.perfilAutor.id,
          name: post.perfilAutor.nombre,
          firstName: post.perfilAutor.nombre.trim().split(/\s+/)[0],
          avatar: post.perfilAutor.imagen,
          faculty: post.perfilAutor.afiliacionUniandes,
        }
      : MIEMBROS_DEMO[post.userId]
    : undefined;

  const goBack = () => {
    if (onBack) {
      onBack();
    } else if (window.history.length > 1) {
      window.history.back();
    } else {
      window.alert('Todavía no hay una pantalla anterior configurada.');
    }
  };

  // ─── Resultado del servidor: no se simulan participaciones reales ───
  const [resultadoParticipacion, setResultadoParticipacion] = useState<ResultadoParticipacion | null>(null);
  const [enviandoParticipacion, setEnviandoParticipacion] = useState(false);
  const [errorParticipacion, setErrorParticipacion] = useState('');
  const [confirmedParticipants, setConfirmedParticipants] = useState<string[]>(
    postDemo?.confirmedParticipants ?? [],
  );
  
  // 05. REINICIAR LA PARTICIPACIÓN AL CAMBIAR DE POST
  useEffect(() => {
    setResultadoParticipacion(null);
    setEnviandoParticipacion(false);
    setErrorParticipacion('');
    setConfirmedParticipants(postDemo?.confirmedParticipants ?? []);
  }, [postId, postDemo]);

  // Evita crear un acuerdo duplicado si el usuario regresa al post o refresca la página.
  // Se consultan tanto los acuerdos pendientes como los realizados; los cancelados
  // no ocupan cupo y permiten volver a participar.
  const [acuerdoExistente, setAcuerdoExistente] = useState<ResultadoParticipacion | null>(null);
  const [consultandoParticipacion, setConsultandoParticipacion] = useState(true);
  const [errorConsultaParticipacion, setErrorConsultaParticipacion] = useState<string | null>(null);
  const [revisionParticipacion, setRevisionParticipacion] = useState(0);

  useEffect(() => {
    let vigente = true;
    setAcuerdoExistente(null);
    setErrorConsultaParticipacion(null);
    if (!postId || postDemo || !currentUserId) {
      setConsultandoParticipacion(false);
      return () => { vigente = false; };
    }
    setConsultandoParticipacion(true);
    void Promise.all([
      obtenerAcuerdosMiembro(currentUserId, 'pendientes'),
      obtenerAcuerdosMiembro(currentUserId, 'completados'),
    ]).then(([pendientes, completados]) => {
      if (!vigente) return;
      const encontrado = [...pendientes, ...completados].find(a => a.postAyuda?.id === postId);
      if (encontrado) {
        setAcuerdoExistente({ acuerdoId: encontrado.id });
      }
    }).catch((error: unknown) => {
      if (vigente) setErrorConsultaParticipacion(
        error instanceof Error ? error.message : 'No se pudo verificar si ya participas.',
      );
    }).finally(() => { if (vigente) setConsultandoParticipacion(false); });
    return () => { vigente = false; };
  }, [postId, postDemo, currentUserId, revisionParticipacion]);

  if (cargandoPost && !post) {
    return <main role="status" className="min-h-screen bg-[#F6F6F6] p-8 text-center text-sm text-[#737373]">Cargando publicación…</main>;
  }

  if (errorPost && !post) {
    return (
      <main role="alert" className="min-h-screen bg-[#F6F6F6] p-8 text-center">
        <p className="text-sm text-[#D32F2F]">{errorPost}</p>
        <button type="button" onClick={() => setReintentarConsulta((valor) => valor + 1)}
          className="mt-3 rounded-xl bg-[#3C9DA0] px-4 py-2 text-sm text-white">Reintentar</button>
      </main>
    );
  }

  // ─── Caso especial: publicación no encontrada ───
  if (!post) {
    return (
      <main
        data-section="publicacion-no-encontrada"
        className="min-h-screen bg-[#F6F6F6] flex items-center justify-center"
      >
        <div className="text-center">
          <p className="text-[#737373]">Publicación no encontrada.</p>
          <button type="button" onClick={goBack} className="mt-4 text-[#3C9DA0] font-medium text-sm">
            Volver
          </button>
        </div>
      </main>
    );
  }

  // ─── Caso especial: autor no encontrado ───
  if (!author) {
    return (
      <main
        data-section="autor-no-encontrado"
        className="min-h-screen bg-[#F6F6F6] flex items-center justify-center text-[#737373]"
      >
        Autor no encontrado.
      </main>
    );
  }

  // ─── Datos de presentación derivados del contrato real o mock legado ───
  const postApi = esPostDelBackend(post) ? post : null;
  const postMock = !esPostDelBackend(post) ? post : null;
  const isOffer = postApi ? postApi.ofrece : postMock!.type === 'help-offer';
  const titulo = postApi ? postApi.titulo : postMock!.title;
  const descripcion = postApi ? postApi.descripcion : postMock!.description;
  const imagen = postApi ? postApi.imagen : postMock!.image;
  const horas = postApi ? postApi.horas : postMock!.estimatedHours;
  const fechaCreacion = postApi
    ? new Intl.DateTimeFormat('es-CO', { dateStyle: 'medium' }).format(new Date(postApi.fechaCreacion))
    : postMock!.createdAt;
  const categorias = postApi
    ? categoriasApi.map((categoria) => categoria.nombre)
    : postMock!.category.split('/').map((categoria) => categoria.trim());
  const confirmedCount = postApi ? null : confirmedParticipants.length;
  const maxSlots = postApi ? postApi.cupo : postMock!.maxParticipants ?? 1;
  const slotsLeft = postApi ? null : maxSlots - confirmedParticipants.length;
  const isFull = postApi ? postApi.cupoLleno : (slotsLeft ?? 0) <= 0;
  // No se inventa un estado de participación del backend. Los duplicados se validan en el servidor.
  const currentUserJoined = postApi
    ? Boolean(resultadoParticipacion || acuerdoExistente)
    : Boolean(resultadoParticipacion) || confirmedParticipants.includes(currentUserId);
  const esAutorPost = Boolean(postApi && currentUserId && postApi.perfilAutor?.id === currentUserId);

  const franjasPropuestas: IntervaloDisponibilidad[] = postApi
    ? (postApi.horariosDisponibles ?? []).map(horarioParaCalendario)
    : (postMock!.availability ?? []);
  const preferidaApi = postApi?.horariosDisponibles?.find(h => h.preferido);
  const franjaPreferida = postApi
    ? preferidaApi ? horarioParaCalendario(preferidaApi) : undefined
    : postMock?.availability?.find(franja => franja.id === postMock.preferredAvailabilityId);
  const fechaPreferida = franjaPreferida
    ? mostrarFechaISO(franjaPreferida.date)
    : postMock?.preferredDate;
  const horaPreferida = franjaPreferida
    ? `${mostrarHora24(franjaPreferida.startTime)} – ${mostrarHora24(franjaPreferida.endTime)}`
    : postMock?.preferredTime;
  const participacionDisponible = Boolean(
    postApi && onParticipar && currentUserId && !esAutorPost &&
    !consultandoParticipacion && !errorConsultaParticipacion,
  );

  // 05. SOLICITAR PARTICIPACIÓN: un solo POST atómico a través de App.
  // El acuerdo y el chat solo se muestran como creados cuando el backend lo confirma.
  async function handleJoin() {
    if (!postApi || !currentUserId || esAutorPost || currentUserJoined || isFull ||
      enviandoParticipacion || !participacionDisponible || !onParticipar) return;
    setEnviandoParticipacion(true);
    setErrorParticipacion('');
    try {
      const resultado = await onParticipar(postApi.id);
      if (!resultado.acuerdoId || !resultado.chatId) {
        throw new Error('La respuesta de participación no contiene los identificadores del acuerdo y su chat.');
      }
      setResultadoParticipacion(resultado);
    } catch (error: unknown) {
      // Ante un timeout no sabemos si el servidor alcanzó a confirmar la transacción.
      // No reintentamos automáticamente para evitar participaciones duplicadas.
      setErrorParticipacion(
        `No pudimos confirmar la participación. Revisa Actividad antes de intentarlo nuevamente.${error instanceof Error && error.message ? ` Detalle: ${error.message}` : ''}`,
      );
    } finally {
      setEnviandoParticipacion(false);
    }
  }

  // 06. CONFIRMACIÓN: solo aparece cuando se recibió un acuerdo válido.
  if (resultadoParticipacion) {
    return (
      <main data-section="pantalla-confirmacion" className="min-h-screen bg-[#F6F6F6] flex flex-col">
        <section
          data-section="confirmacion-participacion"
          aria-label="Confirmación de participación"
          className="flex-1 flex flex-col items-center justify-center px-6 text-center"
        >
          {/* 07.1 ÍCONO DE CONFIRMACIÓN */}
          <div className="w-20 h-20 rounded-full bg-[#3C9DA0] flex items-center justify-center mb-5">
            <Icon name="check" size={36} className="text-white" strokeWidth={3} />
          </div>

          {/* 07.2 MENSAJE DE CONFIRMACIÓN */}
          <h2
            className="text-2xl font-bold text-[#0D0D0D] mb-2"
            style={{ fontFamily: 'Outfit, sans-serif' }}
          >
            ¡Te uniste!
          </h2>
          <p className="text-[#737373] mb-6 leading-relaxed">
            {isOffer
              ? `Puedes consultar el acuerdo de servicio con ${author.firstName}. Las condiciones todavía deben definirse.`
              : `Puedes consultar el acuerdo de servicio para ayudar a ${author.firstName}. Las condiciones todavía deben definirse.`}
          </p>

          {/* 07.3 BOTONES DE LA CONFIRMACIÓN */}
          <div data-section="acciones-confirmacion" className="w-full max-w-xs space-y-3">
            <button
              type="button"
              onClick={() => onVerAcuerdo?.(resultadoParticipacion.acuerdoId)}
              disabled={!onVerAcuerdo}
              className="w-full py-3 rounded-xl bg-[#3C9DA0] text-white font-semibold text-sm btn-press disabled:cursor-not-allowed disabled:opacity-50"
              style={{ fontFamily: 'Outfit, sans-serif' }}
            >
              Ver tu cita
            </button>
            {resultadoParticipacion.chatId && (
              <button
                type="button"
                onClick={() => onIrChat?.(resultadoParticipacion.acuerdoId)}
                disabled={!onIrChat}
                className="w-full py-3 rounded-xl border border-[#E8E8E8] text-[#0D0D0D] font-medium text-sm btn-press disabled:opacity-50"
              >
                Ir al chat
              </button>
            )}
            <button type="button" onClick={() => onVolverInicio?.()} className="text-sm text-[#737373]">
              Volver al inicio
            </button>
          </div>
        </section>
      </main>
    );
  }

  // ─── Vista principal del detalle de la publicación ───
  return (
    <div className="min-h-screen bg-[#F6F6F6]">
      {/* 01. ENCABEZADO SUPERIOR: botón volver, tipo de post y etiqueta */}
      <header
        data-section="encabezado-publicacion"
        className="bg-white px-4 pt-12 pb-3 lg:pt-6 sticky top-0 z-30 shadow-[0_1px_0_#E8E8E8]"
      >
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          {/* Botón para volver a la vista anterior */}
          <button
            type="button"
            aria-label="Volver a la pantalla anterior"
            onClick={goBack}
            className="w-9 h-9 rounded-full bg-[#F6F6F6] flex items-center justify-center flex-shrink-0"
          >
            <Icon name="arrow-left" size={18} className="text-[#0D0D0D]" />
          </button>

          {/* Título del encabezado: oferta o solicitud de ayuda */}
          <h1
            className="flex-1 text-base font-bold text-[#0D0D0D] truncate"
            style={{ fontFamily: 'Outfit, sans-serif' }}
          >
            {isOffer ? 'Detalles del Tiempo' : 'Detalles del Plan'}
          </h1>

          {/* Etiqueta que indica el tipo de publicación */}
          <span
            className={`flex-shrink-0 inline-flex items-center gap-1 text-[10px] font-bold px-2.5 py-1.5 rounded-full uppercase tracking-wide ${
              isOffer ? 'bg-[#FFFF00] text-[#0D0D0D]' : 'bg-[#E8F5F6] text-[#3C9DA0]'
            }`}
          >
            <Icon name={isOffer ? 'star' : 'alert-triangle'} size={11} strokeWidth={2.5} />
            {isOffer ? 'Te tengo el plan' : 'Tengo Tiempo'}
          </span>
        </div>
      </header>

      <main data-section="contenido-detalle-post" className="max-w-2xl mx-auto px-4 py-4 space-y-4">
        {/* 02. IMAGEN DE LA PUBLICACIÓN (solo se muestra si existe) */}
        {imagen && (
          <figure data-section="imagen-publicacion" className="rounded-2xl overflow-hidden h-48 bg-[#E8E8E8]">
            <img src={imagen} alt={titulo} className="w-full h-full object-cover" />
          </figure>
        )}

        {/* 03. TARJETA PRINCIPAL: título, autor, descripción y categorías */}
        <article
          data-section="tarjeta-publicacion"
          className="bg-white rounded-2xl p-5 border border-[#E8E8E8]"
        >
          {/* 03.1 TÍTULO DE LA PUBLICACIÓN */}
          <h2
            className="text-xl font-bold text-[#0D0D0D] mb-3"
            style={{ fontFamily: 'Outfit, sans-serif' }}
          >
            {titulo}
          </h2>

          {/* 03.2 AUTOR: avatar, nombre, facultad y fecha de publicación */}
          <button
            type="button"
            data-section="autor-publicacion"
            onClick={() => onVerPerfil?.(author.id)}
            className="flex items-center gap-3 mb-4 hover:opacity-80 transition-opacity"
          >
            <Avatar name={author.name} avatarUrl={author.avatar} avatarColor={author.avatarColor} size="md" />
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-sm text-[#0D0D0D]">{author.name}</span>
                <Icon name="check-circle" size={14} className="text-[#3C9DA0]" strokeWidth={2.5} />
              </div>
              <p className="text-xs text-[#737373]">
                {author.faculty ? `${author.faculty} · ` : ''}
                {fechaCreacion}
              </p>
            </div>
            <span className="ml-auto text-xs text-[#3C9DA0] font-medium">Ver perfil →</span>
          </button>

          {/* 03.3 DESCRIPCIÓN DE LA AYUDA */}
          <p data-section="descripcion-publicacion" className="text-sm text-[#737373] leading-relaxed mb-4">
            {descripcion}
          </p>

          {/* 03.4 CATEGORÍAS DE LA PUBLICACIÓN */}
          <div data-section="categorias-publicacion" className="flex flex-wrap gap-2 mb-4">
            {categorias.map((categoria) => (
              <Chip key={categoria} label={categoria} size="sm" color="teal" />
            ))}
          </div>
        </article>

        {/* 04. DETALLES DE LA PUBLICACIÓN: fecha, duración y cupos */}
        <section
          data-section="detalles-publicacion"
          aria-label="Detalles de la publicación"
          className="bg-white rounded-2xl p-5 border border-[#E8E8E8] space-y-3"
        >
          <h3
            className="text-sm font-bold text-[#0D0D0D] mb-1"
            style={{ fontFamily: 'Outfit, sans-serif' }}
          >
            Detalles
          </h3>

          {/* 04.1 HORARIO PREFERIDO (propuesta, no horario confirmado) */}
          {(fechaPreferida || horaPreferida) && (
            <div data-section="horario-preferido" className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#FFFDE0] flex items-center justify-center flex-shrink-0">
                <Icon name="calendar" size={17} className="text-[#5A5A00]" strokeWidth={2} />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-[#9E9E9E] uppercase tracking-wide font-medium">
                  Horario preferido
                </p>
                <p className="text-sm font-semibold text-[#0D0D0D] capitalize">
                  {fechaPreferida}{horaPreferida ? ` · ${horaPreferida}` : ''}
                </p>
                <p className="mt-1 text-xs text-[#737373]">
                  Es una preferencia del autor, no un horario confirmado.
                </p>
              </div>
            </div>
          )}

          {/* 04.2 DURACIÓN ESTIMADA (cuando está definida) */}
          {horas != null && (
            <div data-section="duracion-estimada" className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#E8F5F6] flex items-center justify-center flex-shrink-0">
                <Icon name="clock" size={17} className="text-[#3C9DA0]" strokeWidth={2} />
              </div>
              <div>
                <p className="text-[10px] text-[#9E9E9E] uppercase tracking-wide font-medium">Duración</p>
                <p className="text-sm font-semibold text-[#0D0D0D]">
                  {horas} hora{horas !== 1 ? 's' : ''}
                </p>
              </div>
            </div>
          )}

          {/* 04.3 PARTICIPANTES: cupos disponibles y personas confirmadas */}
          <div data-section="participantes" className="flex items-center gap-3">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                isFull ? 'bg-[#F0F0F0]' : 'bg-[#E8F5F6]'
              }`}
            >
              <Icon
                name="users"
                size={17}
                className={isFull ? 'text-[#9E9E9E]' : 'text-[#3C9DA0]'}
                strokeWidth={2}
              />
            </div>
            <div>
              <p className="text-[10px] text-[#9E9E9E] uppercase tracking-wide font-medium">Participantes</p>
              <p className={`text-sm font-semibold ${isFull ? 'text-[#9E9E9E]' : 'text-[#0D0D0D]'}`}>
                {isFull
                  ? 'Cupos completos'
                  : postApi
                    ? `Cupo máximo: ${maxSlots}`
                    : `${slotsLeft} de ${maxSlots} cupo${maxSlots !== 1 ? 's' : ''} disponible${slotsLeft !== 1 ? 's' : ''}`}
              </p>
              {confirmedCount != null && confirmedCount > 0 && (
                <p className="text-xs text-[#737373] mt-0.5">
                  {confirmedCount} confirmado{confirmedCount !== 1 ? 's' : ''}
                </p>
              )}
            </div>
          </div>
        </section>

        {/* 04.4 CALENDARIO DE DISPONIBILIDAD PROPUESTA POR EL AUTOR */}
        {typeof horas === 'number' && horas > 0 ? (
          <CalendarioDisponibilidadPostAyuda
            intervalos={franjasPropuestas}
            idPreferido={franjaPreferida?.id}
            duracion={horas}
          />
        ) : (
          <section
            data-section="disponibilidad-sin-duracion"
            className="rounded-2xl border border-[#E8E8E8] bg-white p-4"
          >
            <h3 className="text-sm font-bold text-[#0D0D0D]">Disponibilidad propuesta</h3>
            <p className="mt-1 text-xs text-[#737373]">
              Aún no se ha definido una duración para esta publicación.
            </p>
          </section>
        )}

        {/* 05. EXPLICACIÓN DE LA PARTICIPACIÓN: ¿dar o recibir ayuda? */}
        <aside
          data-section="explicacion-participacion"
          className={`rounded-2xl p-4 border ${
            isOffer ? 'bg-[#FFFDE7] border-[#FFF176]' : 'bg-[#E8F5F6] border-[#B2DFE0]'
          }`}
        >
          <div className="flex items-start gap-3">
            <div
              className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                isOffer ? 'bg-[#FFFF00]' : 'bg-[#3C9DA0]'
              }`}
            >
              <Icon
                name={isOffer ? 'star' : 'help-circle'}
                size={16}
                className={isOffer ? 'text-[#0D0D0D]' : 'text-white'}
                strokeWidth={2}
              />
            </div>
            <div>
              <p
                className="text-sm font-semibold text-[#0D0D0D]"
                style={{ fontFamily: 'Outfit, sans-serif' }}
              >
                {isOffer ? `${author.firstName} comparte tiempo` : `${author.firstName} tiene un plan`}
              </p>
              <p className="text-xs text-[#737373] mt-0.5 leading-relaxed">
                {isOffer
                  ? `Al unirte, recibirás la ayuda de ${author.firstName}. Se creará un acuerdo de servicio automáticamente.`
                  : `Al unirte, le brindarás tu ayuda a ${author.firstName}. Se creará un acuerdo de servicio automáticamente.`}
              </p>
            </div>
          </div>
        </aside>

        {/* 06. BOTÓN PRINCIPAL: unirse a la oferta o solicitud */}
        <section
          data-section="accion-participacion"
          aria-label="Participar en la publicación"
          className="pb-4"
        >
          {acuerdoExistente && !resultadoParticipacion ? (
            <div className="space-y-2">
              <button type="button" onClick={() => onVerAcuerdo?.(acuerdoExistente.acuerdoId)}
                disabled={!onVerAcuerdo}
                className="w-full rounded-2xl bg-[#3C9DA0] py-4 text-base font-bold text-white disabled:opacity-50">
                Ver mi cita
              </button>
              {onIrChat && (
                <button type="button" onClick={() => onIrChat?.(acuerdoExistente.acuerdoId)}
                  disabled={!onIrChat}
                  className="w-full rounded-2xl border border-[#E8E8E8] bg-white py-3 text-sm font-semibold text-[#3C9DA0] disabled:opacity-50">
                  Ir al chat de la cita
                </button>
              )}
            </div>
          ) : <button
            type="button"
            onClick={handleJoin}
            disabled={isFull || esAutorPost || currentUserJoined || enviandoParticipacion || !participacionDisponible}
            className={`w-full py-4 rounded-2xl font-bold text-base btn-press transition-all ${
              isFull || esAutorPost || currentUserJoined || enviandoParticipacion || !participacionDisponible
                ? 'bg-[#F0F0F0] text-[#9E9E9E]'
                : 'bg-[#3C9DA0] text-white hover:bg-[#2D8B8E] shadow-lg shadow-[#3C9DA0]/20'
            }`}
            style={{ fontFamily: 'Outfit, sans-serif' }}
          >
            {enviandoParticipacion
              ? 'Continuando…'
              : consultandoParticipacion
              ? 'Comprobando participación…'
              : currentUserJoined
              ? 'Ya estás participando'
              : esAutorPost
                ? 'Es tu publicación'
              : isFull
                ? 'Cupos completos'
                : isOffer
                  ? 'Aceptar su tiempo'
                  : 'Participar'}
          </button>}
          {errorParticipacion && (
            <p className="mt-2 text-sm text-[#D32F2F]" role="alert">{errorParticipacion}</p>
          )}
          {errorConsultaParticipacion && !esAutorPost && !acuerdoExistente && (
            <div className="mt-2 text-sm text-[#D32F2F]" role="alert">
              <p>No se pudo comprobar si ya estás participando: {errorConsultaParticipacion}</p>
              <button type="button" className="mt-1 font-semibold underline"
                onClick={() => setRevisionParticipacion(v => v + 1)}>Volver a comprobar</button>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

