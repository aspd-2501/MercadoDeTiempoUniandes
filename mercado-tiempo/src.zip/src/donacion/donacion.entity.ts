/* eslint-disable prettier/prettier */
/* archivo: src/donacion/donacion.entity.ts */
import { Check, Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { PerfilMiembroEntity } from '../perfil-miembro/perfil-miembro.entity';
import { DepositoHorasEntity } from '../deposito-horas/deposito-horas.entity';
import { CausaEntity } from '../causa/causa.entity';

@Entity()
@Check(`
    (CASE WHEN "idPerfilDonante" IS NOT NULL THEN 1 ELSE 0 END) +
    (CASE WHEN "idDepositoDonante" IS NOT NULL THEN 1 ELSE 0 END) = 1
`)
@Check(`
    (CASE WHEN "idPerfilReceptor" IS NOT NULL THEN 1 ELSE 0 END) +
    (CASE WHEN "idDepositoReceptor" IS NOT NULL THEN 1 ELSE 0 END) = 1
`)
@Check(`"idPerfilDonante" IS NULL OR "idPerfilDonante" <> "idPerfilReceptor"`)
@Check(`"idDepositoDonante" IS NULL OR "idDepositoDonante" <> "idDepositoReceptor"`)
export class DonacionEntity {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column()
    horasDonadas: number;

    @Column()
    fechaDonacion: Date;

    @Column()
    mensaje: string;

    // --- Donante: perfil o depósito (exactamente uno, validado por CHECK) ---
    @ManyToOne(() => PerfilMiembroEntity, perfil => perfil.donacionesHechas, { nullable: true })
    @JoinColumn({ name: 'idPerfilDonante' })
    perfilDonante: PerfilMiembroEntity;

    @ManyToOne(() => DepositoHorasEntity, deposito => deposito.donacionesComoDonante, { nullable: true })
    @JoinColumn({ name: 'idDepositoDonante' })
    depositoDonante: DepositoHorasEntity;

    // --- Receptor: perfil o depósito (exactamente uno, validado por CHECK) ---
    @ManyToOne(() => PerfilMiembroEntity, perfil => perfil.donacionesRecibidas, { nullable: true })
    @JoinColumn({ name: 'idPerfilReceptor' })
    perfilReceptor: PerfilMiembroEntity;

    @ManyToOne(() => DepositoHorasEntity, deposito => deposito.donacionesComoReceptor, { nullable: true })
    @JoinColumn({ name: 'idDepositoReceptor' })
    depositoReceptor: DepositoHorasEntity;

    // --- Causa a la que se dona (opcional) ---
    @ManyToOne(() => CausaEntity, causa => causa.donaciones, { nullable: true, onDelete: 'SET NULL' })
    @JoinColumn({ name: 'idCausa' })
    causa: CausaEntity;
}
