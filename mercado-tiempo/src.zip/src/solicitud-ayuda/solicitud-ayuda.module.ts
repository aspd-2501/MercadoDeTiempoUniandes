/* eslint-disable prettier/prettier */
/* archivo: src/solicitud-ayuda/solicitud-ayuda.module.ts */
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SolicitudAyudaService } from './solicitud-ayuda.service';
import { SolicitudAyudaEntity } from './solicitud-ayuda.entity';
import { PerfilMiembroEntity } from '../perfil-miembro/perfil-miembro.entity';
import { PerfilOrganizacionEntity } from '../perfil-organizacion/perfil-organizacion.entity';
import { ServicioOfrecidoEntity } from '../servicio-ofrecido/servicio-ofrecido.entity';
import { SolicitudAyudaController } from './solicitud-ayuda.controller';

@Module({
    imports: [TypeOrmModule.forFeature([
        SolicitudAyudaEntity,
        PerfilMiembroEntity,
        PerfilOrganizacionEntity,
        ServicioOfrecidoEntity,
    ])],
    providers: [SolicitudAyudaService],
    controllers: [SolicitudAyudaController],
})
export class SolicitudAyudaModule {}