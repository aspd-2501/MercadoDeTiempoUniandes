/* eslint-disable prettier/prettier */
/* archivo: src/auth/jwt-auth.guard.ts */
import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {}